import styled from "styled-components";

export const Container = styled.div`
  padding: 0 calc(12vw - 35px); //? 1920 - 195 | 375 - 10
  margin-top: calc(4.4vw + 62px); //? 146 - 1920 | 85 - 530
`;
